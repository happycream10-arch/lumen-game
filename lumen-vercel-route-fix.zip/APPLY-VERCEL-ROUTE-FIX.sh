#!/usr/bin/env bash
set -euo pipefail

# Run from the lumen-game repository root after extracting the route-fix ZIP.
rm -f api/'[...path].mjs'
npm test
npm run build
rm -f lumen-vercel-route-fix.zip APPLY-VERCEL-ROUTE-FIX.sh
git add -A
git commit -m "Fix Vercel API route mapping"
git push
