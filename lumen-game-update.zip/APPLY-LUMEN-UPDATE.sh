#!/usr/bin/env bash
set -euo pipefail

# Run from the lumen-game repository root after extracting lumen-game-update.zip.
rm -f api/'[...path].mjs'
npm install
npm run build
npm test
rm -f lumen-game-update.zip lumen-vercel-neon-update.zip lumen-vercel-route-fix.zip APPLY-LUMEN-UPDATE.sh APPLY-VERCEL-NEON.sh APPLY-VERCEL-ROUTE-FIX.sh
git add -A
git commit -m "Improve coin rewards and friend duels"
git push
