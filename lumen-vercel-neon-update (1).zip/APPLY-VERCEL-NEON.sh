#!/usr/bin/env bash
set -euo pipefail

# Run from the lumen-game repository root after extracting lumen-vercel-neon-update.zip.
npm install
npm test
npm run build
rm -f lumen-vercel-neon-update.zip APPLY-VERCEL-NEON.sh
git add -A
git commit -m "Connect Vercel API to Neon"
git push
